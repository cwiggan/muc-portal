<?php

return array(

	'comment_management'    => 'Blog Comment Management',
	'comment_update'        => 'Update a Blog Comment',
	'comment_delete'        => 'Delete a Blog Comment',
	'create_a_new_comment'  => 'Create a New Blog Comment',

);