<?php

return array(

	'role_management'    => 'Role Management',
	'role_update'        => 'Update a Role',
	'role_delete'        => 'Delete a Role',
	'create_a_new_role'  => 'Create a New Role',

);