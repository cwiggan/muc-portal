<?php

return array(

	'title'      => 'Comentário',
	'user_id'   => '# de Comentários',
	'created_at' => 'Criado em',

);
