<?php

return array(

	'name'       => 'Nome',
	'users'      => '# de Usuários',
	'created_at' => 'Criado em',

);
