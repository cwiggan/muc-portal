@extends('site.layouts.default')

{{-- Content --}}
@section('content')

        <h1>Edit MCIR Log</h1>
            {{ Form::model($mcirlog, array('route' => array('mric.update', $mcirlog->id),'method' => 'PUT','class' => 'form-horizontal')) }}
            <div class="form-group">
                <label for="first_name" class="col-sm-2 control-label">First Name</label>
                <div class="col-sm-10">
                  {{ Form::text('first_name') }}
                </div>
              </div>
              <div class="form-group">
                <label for="last_name" class="col-sm-2 control-label">Last Name</label>
                <div class="col-sm-10">
                  {{ Form::text('last_name') }}
                </div>
              </div>
            <div class="form-group">
                <label for="address" class="col-sm-2 control-label">Address</label>
                <div class="col-sm-10">
                  {{ Form::text('address') }}
                </div>
              </div>
              <div class="form-group">
                <label for="phone" class="col-sm-2 control-label">Phone Number</label>
                <div class="col-sm-10">
                  {{ Form::text('phone') }}
                </div>
              </div>
            <div class="form-group">
                <label for="dob" class="col-sm-2 control-label">Date of Birth</label>
                <div class="col-sm-10">
                  {{ Form::text('dob') }}
                </div>
              </div>
                <hr/>
              <div class="form-group">
                <label for="date" class="col-sm-2 control-label">Date</label>
                <div class="col-sm-10">
                  {{ Form::text('date') }}
                </div>
              </div>
              <div class="form-group">
                <label for="vaccine" class="col-sm-2 control-label">Vaccine</label>
                <div class="col-sm-10">
                  {{ Form::text('vaccine') }}
                </div>
              </div>
              <div class="form-group">
                <label for="site" class="col-sm-2 control-label">Site/Route</label>
                <div class="col-sm-10">
                  {{ Form::text('site') }}
                </div>
              </div>
              <div class="form-group">
                <label for="mcg_id" class="col-sm-2 control-label">MFG #</label>
                <div class="col-sm-10">
                  {{ Form::text('mcg_id') }}
                </div>
              </div>
              <div class="form-group">
                <label for="init" class="col-sm-2 control-label">Init</label>
                <div class="col-sm-10">
                  {{ Form::text('init') }}
                </div>
              </div>
              <div class="form-group">
                <label for="exp_date" class="col-sm-2 control-label">Expire Date</label>
                <div class="col-sm-10">
                  {{ Form::text('exp_date') }}
                </div>
              </div>
              <div class="form-group">
                <label for="put_in_mcir" class="col-sm-2 control-label">Put in Mcir</label>
                <div class="col-sm-10">
                  {{ Form::checkbox('put_in_mcir') }}
                </div>
              </div>
                {{ Form::submit('Submit'); }}
            {{ Form::close() }}


@stop