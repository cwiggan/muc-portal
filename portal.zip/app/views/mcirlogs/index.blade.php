@extends('site.layouts.default')

{{-- Content --}}
@section('content')
	<div class="page-header">
		<h3>
                        Mcir Log
			<div class="pull-right">
				<a href="{{{ URL::to('mcir/create') }}}" class="btn btn-small btn-info iframe"><span class="glyphicon glyphicon-plus-sign"></span> Create</a>
			</div>
		</h3>
	</div>

	<table id="blogs" class="table table-striped table-hover">
		<thead>
			<tr>
				<th class="col-md-4">First Name</th>
				<th class="col-md-2">Last Name </th>
				<th class="col-md-2">Created</th>
				<th class="col-md-2">{{{ Lang::get('table.actions') }}}</th>
			</tr>
                            
		</thead>
		<tbody>
                @foreach ($mcirlogs as $log)
                    <tr>
                        <td>{{ $log->first_name }}</td>
                        <td>{{ $log->last_name }}</td>
                        <td>{{ $log->created_at }}</td>
                        <td>{{ link_to_route('mcir.show', 'view', $parameters = array($log->id), $attributes = array()) }}</td>
                    </tr>
                @endforeach
                
		</tbody>
	</table>
@stop

{{-- Scripts --}}
@section('scripts')
	<script type="text/javascript">
		var oTable;
		$(document).ready(function() {
			oTable = $('#blogs').dataTable( {
				"sDom": "<'row'<'col-md-6'l><'col-md-6'f>r>t<'row'<'col-md-6'i><'col-md-6'p>>",
				"sPaginationType": "bootstrap",
				"oLanguage": {
					"sLengthMenu": "_MENU_ records per page"
				},
				"bProcessing": true,
		        "bServerSide": true,
		        "sAjaxSource": "{{ URL::to('admin/blogs/data') }}",
		        "fnDrawCallback": function ( oSettings ) {
	           		$(".iframe").colorbox({iframe:true, width:"80%", height:"80%"});
	     		}
			});
		});
	</script>
@stop