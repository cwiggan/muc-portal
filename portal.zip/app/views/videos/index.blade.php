@extends('site.layouts.default')

{{-- Content --}}
@section('content')
<div class="row">
@foreach ($videos as $video)
		
			<div class="col-md-6">
				<h4>
                                {{ link_to_route('videos.show', $video->title, $parameters = array($video->id), $attributes = array()) }}
                                </h4>
                                <p>{{{ $video->desc }}}</p>
			</div>
		

@endforeach
</div>


@stop
