@extends('site.layouts.default')

{{-- Content --}}
@section('content')

        <h1>{{ $video->title }}</h1>
<iframe src="//player.vimeo.com/video/{{ $video->name }}" width="500" height="282" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>
 <p>{{ $video->desc }}</p>   
@stop